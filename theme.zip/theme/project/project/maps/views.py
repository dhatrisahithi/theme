import requests
from django.shortcuts import render


def default_map(request):
          # TODO: move this token to Django settings from an environment variable
          # found in the Mapbox account settings and getting started instructions
          # see https://www.mapbox.com/account/ under the "Access tokens" section
          url = 'http://api.airpollutionapi.com/1.0/aqi?lat={}&lon={}&APPID=9fnlip0llc3r0k55lbtev9hoqn'
          latitide = 28.7040590
          longitude = 77.10249
          r = requests.get(url.format(latitide,longitude)).json()
          pollution = {
              'text': r['data']['text'],
              'aqi_value' : r['data']['aqiParams'][0]['value'],
              'country' : r['data']['country'] 
           }
          context = { 'pollution': pollution}
          return render(request, 'default.html',context)


def home1(request):
         return render(request, 'home1.html')

def info(request):
         return render(request, 'info.html')

def aircomp(request):
         return render(request, 'aircomp.html')

def countries(request):
         return render(request, 'countries.html')
    
